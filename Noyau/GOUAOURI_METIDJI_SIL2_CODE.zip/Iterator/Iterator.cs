﻿using System;

namespace WpfApp2.Iterator
{
    public interface Iterator
    {
        Boolean encore();
        Object suivant();
        
    }
}