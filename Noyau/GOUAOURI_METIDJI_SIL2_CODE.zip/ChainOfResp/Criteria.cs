namespace WpfApp2.ChainOfResp
{
    public class Criteria
    {

    }
}