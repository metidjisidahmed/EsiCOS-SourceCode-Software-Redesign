﻿namespace WpfApp2.Prets_Factory_Pattern
{
    public class PretRemboursable : Pret
    {
        
    }
}