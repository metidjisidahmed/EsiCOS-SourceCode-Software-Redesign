﻿namespace WpfApp2.Prets_Factory_Pattern
{
    public abstract class Pret
    {
        // LES methodes abstraites du pretRemboursbale / PretNonRemboursble
    }
}