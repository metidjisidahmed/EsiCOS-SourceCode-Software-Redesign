﻿namespace WpfApp2.Prets_Factory_Pattern
{
    public class Pret_Social : PretRemboursable
    {
        
    }
}