﻿namespace WpfApp2.Prets_Factory_Pattern
{
    public class Pret_Electromenager_Non_Remborsable : PretNonRemboursable
    {
        
    }
}