﻿namespace WpfApp2.Prets_Factory_Pattern
{
    public class PretNonRemboursable : Pret
    {
        
    }
}